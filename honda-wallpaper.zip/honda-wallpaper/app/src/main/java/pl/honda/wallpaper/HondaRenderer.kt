package pl.honda.wallpaper

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class HondaRenderer(private val ctx: Context) : GLSurfaceView.Renderer {

    private var program = 0
    private var texImage = 0
    private var texNoise = 0
    private var imgW = 1280
    private var imgH = 720
    private var surfW = 1
    private var surfH = 1
    private val startMs = SystemClock.elapsedRealtime()

    private val quad = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
        }

    private var uTex = 0; private var uNoise = 0; private var uTexel = 0
    private var uCover = 0; private var uFlow = 0; private var uSweep = 0; private var uPulse = 0
    private var aPos = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        program = buildProgram(VERTEX, FRAGMENT)
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        uTex = GLES20.glGetUniformLocation(program, "uTex")
        uNoise = GLES20.glGetUniformLocation(program, "uNoise")
        uTexel = GLES20.glGetUniformLocation(program, "uTexel")
        uCover = GLES20.glGetUniformLocation(program, "uCover")
        uFlow = GLES20.glGetUniformLocation(program, "uFlow")
        uSweep = GLES20.glGetUniformLocation(program, "uSweep")
        uPulse = GLES20.glGetUniformLocation(program, "uPulse")
        loadImage()
        makeNoise()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfW = maxOf(width, 1); surfH = maxOf(height, 1)
        GLES20.glViewport(0, 0, surfW, surfH)
    }

    override fun onDrawFrame(gl: GL10?) {
        val t = (SystemClock.elapsedRealtime() - startMs) / 1000f

        // przycięcie obrazka tak, żeby wypełniał ekran (jak "cover")
        val sa = surfW.toFloat() / surfH
        val ia = imgW.toFloat() / imgH
        val cx = if (sa > ia) 1f else sa / ia
        val cy = if (sa > ia) ia / sa else 1f

        val flowA = (t / 160f) % 1f          // dryf chmur (zapętla się bez skoku)
        val flowB = (t / 260f) % 1f          // wolniejsze "falowanie" chmur
        val sweep = (t % 11f) / 5f           // 0..1 = przejście błysku, dalej przerwa
        val pulse = 0.5f + 0.5f * Math.sin(2.0 * Math.PI * (t % 9f) / 9f).toFloat()

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImage)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texNoise)
        GLES20.glUniform1i(uNoise, 1)

        GLES20.glUniform2f(uTexel, 1f / imgW, 1f / imgH)
        GLES20.glUniform2f(uCover, cx, cy)
        GLES20.glUniform2f(uFlow, flowA, flowB)
        GLES20.glUniform1f(uSweep, sweep)
        GLES20.glUniform1f(uPulse, pulse)

        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    private fun loadImage() {
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.wallpaper_base, opts)
        imgW = bmp.width; imgH = bmp.height
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texImage = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texImage)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        bmp.recycle()
    }

    /** Mała tekstura losowego szumu (64x64) - z niej powstają chmury. */
    private fun makeNoise() {
        val n = 64
        val data = ByteArray(n * n * 4)
        Random(7).nextBytes(data)
        val buf = ByteBuffer.allocateDirect(data.size).order(ByteOrder.nativeOrder())
        buf.put(data); buf.position(0)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        texNoise = ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texNoise)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_REPEAT)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, n, n, 0,
            GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader error: $log")
        }
        return s
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val VERTEX = """
attribute vec2 aPos;
uniform vec2 uCover;
varying vec2 vUv;
void main() {
    vec2 uv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
    vUv = (uv - 0.5) * uCover + 0.5;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

        private const val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform sampler2D uTex;
uniform sampler2D uNoise;
uniform vec2 uTexel;
uniform vec2 uFlow;
uniform float uSweep;
uniform float uPulse;
varying vec2 vUv;

const float AR = 1.7778;
const vec2 SUN = vec2(0.855, 0.77);

float lumOf(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

float rectMask(vec2 uv, vec2 lo, vec2 hi) {
    vec2 a = smoothstep(lo - 0.01, lo + 0.01, uv);
    vec2 b = 1.0 - smoothstep(hi - 0.01, hi + 0.01, uv);
    return a.x * a.y * b.x * b.y;
}

void main() {
    vec2 uv = vUv;
    vec2 p = vec2(uv.x * AR, uv.y);
    vec2 sunP = vec2(SUN.x * AR, SUN.y);

    // --- krawędź Ziemi (horyzont) ---
    float yh = 0.708 + 0.769 * (uv.x - 0.484) * (uv.x - 0.484) - 0.05 * uv.x;
    float d = uv.y - yh;
    float earth = smoothstep(0.015, 0.075, d);

    vec3 col;
    float cloud = 0.0;
    vec3 cloudCol = vec3(0.0);

    if (earth > 0.0) {
        // współrzędne szumu: im bliżej horyzontu, tym chmury bardziej rozciągnięte
        vec2 nc = vec2(p.x * 0.15, pow(max(d, 0.0), 0.6) * 1.35);

        vec2 w = texture2D(uNoise, nc * 0.5 + vec2(uFlow.y, 0.5)).gb - 0.5;

        vec3 n1 = texture2D(uNoise, nc + vec2(uFlow.x, 0.0)).rgb;
        vec3 n2 = texture2D(uNoise, nc * 2.0 + vec2(uFlow.x * 2.0, 0.0) + vec2(0.31, 0.17)).rgb;
        vec3 n3 = texture2D(uNoise, nc * 4.0 + vec2(uFlow.x * 4.0, 0.0) + vec2(0.62, 0.44)).rgb;
        vec3 f = n1 * 0.5 + n2 * 0.3 + n3 * 0.2;

        // delikatne przesuwanie istniejących chmur z obrazka
        vec2 disp = (f.gb - 0.5) * 0.020 * earth;
        col = texture2D(uTex, uv + disp).rgb;

        // dodatkowa warstwa płynących chmur
        float c = f.r + w.x * 0.35;
        cloud = smoothstep(0.50, 0.68, c) * earth;

        // chmury jaśniejsze po stronie słońca, ciemne i niebieskawe po drugiej
        float lit = clamp(1.0 - distance(p, sunP) * 0.75, 0.0, 1.0);
        cloudCol = mix(vec3(0.10, 0.16, 0.30), vec3(1.0, 0.93, 0.84), lit * lit);

        col = col * (1.0 - 0.30 * cloud) + cloudCol * cloud * 0.55;
    } else {
        col = texture2D(uTex, uv).rgb;
    }

    // --- światło słońca na chromowanym logo i napisie ---
    float lum = lumOf(col);
    float region = max(rectMask(uv, vec2(0.385, 0.125), vec2(0.615, 0.46)),
                       rectMask(uv, vec2(0.17, 0.505), vec2(0.82, 0.605)));
    float chrome = region * smoothstep(0.18, 0.40, lum);

    if (chrome > 0.0) {
        // pseudo-wypukłość z jasności obrazka (krawędzie chromu)
        vec2 t2 = uTexel * 2.0;
        float lx1 = lumOf(texture2D(uTex, uv + vec2(t2.x, 0.0)).rgb);
        float lx2 = lumOf(texture2D(uTex, uv - vec2(t2.x, 0.0)).rgb);
        float ly1 = lumOf(texture2D(uTex, uv + vec2(0.0, t2.y)).rgb);
        float ly2 = lumOf(texture2D(uTex, uv - vec2(0.0, t2.y)).rgb);
        vec3 N = normalize(vec3((lx2 - lx1) * 3.0, (ly2 - ly1) * 3.0, 0.6));

        // kierunek światła ze słońca (lekko się "oddycha")
        vec3 L = normalize(vec3((sunP - p), 0.30 + 0.25 * uPulse));
        vec3 H = normalize(L + vec3(0.0, 0.0, 1.0));
        float spec = pow(max(dot(N, H), 0.0), 16.0);
        float dif = max(dot(N, L), 0.0);

        float warm = clamp(1.0 - distance(p, sunP) * 0.8, 0.0, 1.0);
        vec3 lc = mix(vec3(1.0, 0.92, 0.82), vec3(1.0, 0.55, 0.25), warm);

        // błysk przesuwający się po chromie od strony słońca
        float s = dot(p, vec2(-0.94, 0.34));
        float pos = mix(-1.55, 0.25, uSweep);
        float x = (s - pos) / 0.07;
        float band = exp(-x * x);

        vec3 add = (spec * 0.9 + dif * 0.10 * (0.8 + 0.2 * uPulse)) * lc
                 + band * (0.35 + lum) * vec3(1.0, 0.88, 0.70) * 0.85;
        col += chrome * add;
        col += chrome * warm * lum * 0.18 * vec3(1.0, 0.5, 0.2);
    }

    // delikatna pulsacja blasku słońca
    float ds = distance(p, sunP);
    col += vec3(1.0, 0.5, 0.15) * exp(-ds * ds * 90.0) * 0.10 * uPulse;

    gl_FragColor = vec4(col, 1.0);
}
"""
    }
}
